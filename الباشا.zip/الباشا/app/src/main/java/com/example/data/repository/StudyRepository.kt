package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.local.PdfGuideManager
import com.example.data.local.PdfProcessResult
import com.example.data.local.SampleStudyGuides
import com.example.data.local.StudyTutorEngine
import com.example.data.model.Chapter
import com.example.data.model.ChatMessage
import com.example.data.model.DailyUsage
import com.example.data.model.QuizSession
import com.example.data.model.SenderType
import com.example.data.model.StudyGuide
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

sealed class BannerStatus {
    data class Success(val message: String) : BannerStatus()
    data class Warning(val message: String) : BannerStatus()
    data class Error(val message: String) : BannerStatus()
}

class StudyRepository {

    private val _studyGuides = MutableStateFlow<List<StudyGuide>>(SampleStudyGuides.sampleGuidesList)
    val studyGuides: StateFlow<List<StudyGuide>> = _studyGuides.asStateFlow()

    private val _activeGuide = MutableStateFlow<StudyGuide>(SampleStudyGuides.biologyGuide)
    val activeGuide: StateFlow<StudyGuide> = _activeGuide.asStateFlow()

    private val _chatMessagesMap = MutableStateFlow<Map<String, List<ChatMessage>>>(
        mapOf(
            SampleStudyGuides.biologyGuide.id to listOf(
                ChatMessage(
                    id = "init_bio",
                    guideId = SampleStudyGuides.biologyGuide.id,
                    sender = SenderType.ASSISTANT,
                    text = "مرحبًا بك في مذاكرة \"ملزمة الأحياء: الخلية وعلم الوراثة\"! 🧬\nأنا مساعدك التعليمي، جاهز للإجابة على كل استفساراتك وتوليد اختبارات من محتوى هذه الملزمة فقط. ما الذي تود مراجعته أولاً؟",
                    citedSection = "الملزمة المرفوعة كاملة",
                    suggestedFollowUps = listOf(
                        "لخص لي المفهوم الرئيسي",
                        "أهم القوانين والتعريفات",
                        "اشرح لي تركيب الميتوكوندريا",
                        "ما هو كودون البدء؟"
                    )
                )
            )
        )
    )
    val chatMessagesMap: StateFlow<Map<String, List<ChatMessage>>> = _chatMessagesMap.asStateFlow()

    private val _currentQuizSession = MutableStateFlow<QuizSession?>(null)
    val currentQuizSession: StateFlow<QuizSession?> = _currentQuizSession.asStateFlow()

    private val _quizHistory = MutableStateFlow<List<QuizSession>>(emptyList())
    val quizHistory: StateFlow<List<QuizSession>> = _quizHistory.asStateFlow()

    private val _dailyUsage = MutableStateFlow(DailyUsage())
    val dailyUsage: StateFlow<DailyUsage> = _dailyUsage.asStateFlow()

    private val _bannerStatus = MutableStateFlow<BannerStatus?>(null)
    val bannerStatus: StateFlow<BannerStatus?> = _bannerStatus.asStateFlow()

    /**
     * Loads persisted uploaded guides from local storage.
     */
    fun loadStoredGuides(context: Context) {
        val persisted = PdfGuideManager.loadPersistedGuides(context)
        if (persisted.isNotEmpty()) {
            val combined = (persisted + SampleStudyGuides.sampleGuidesList).distinctBy { it.id }
            _studyGuides.value = combined
            if (_activeGuide.value.id == SampleStudyGuides.biologyGuide.id) {
                setActiveGuide(persisted.first().id)
            }
        }
    }

    suspend fun uploadPdf(context: Context, uri: Uri, customSubject: String?): PdfProcessResult {
        val result = PdfGuideManager.processPdfUpload(context, uri, customSubject)
        when (result) {
            is PdfProcessResult.Success -> {
                val updatedList = (listOf(result.guide) + _studyGuides.value).distinctBy { it.id }
                _studyGuides.value = updatedList
                setActiveGuide(result.guide.id)
                _bannerStatus.value = BannerStatus.Success(result.message)
            }
            is PdfProcessResult.Error -> {
                _bannerStatus.value = BannerStatus.Error(result.errorMessage)
            }
        }
        return result
    }

    fun setActiveGuide(guideId: String) {
        val found = _studyGuides.value.find { it.id == guideId }
        if (found != null) {
            _activeGuide.value = found
            if (!_chatMessagesMap.value.containsKey(guideId)) {
                val welcome = ChatMessage(
                    id = UUID.randomUUID().toString(),
                    guideId = guideId,
                    sender = SenderType.ASSISTANT,
                    text = "أهلاً بك! تم تفعيل ملزمة \"${found.title}\". يمكنك سؤالي عن أي مفهوم أو مسألة فيها، أو بدء اختبار MCQ.",
                    citedSection = "الملزمة النشطة: ${found.title}",
                    suggestedFollowUps = listOf(
                        "لخص لي المفهوم الرئيسي",
                        "أهم القوانين والتعريفات",
                        "اشرح لي الصفحة الأخيرة ببساطة"
                    )
                )
                _chatMessagesMap.value = _chatMessagesMap.value + (guideId to listOf(welcome))
            }
        }
    }

    fun addCustomGuide(title: String, subject: String, rawContent: String): StudyGuide {
        val wordCount = rawContent.split("\\s+".toRegex()).filter { it.isNotBlank() }.size
        val pageCount = (wordCount / 180).coerceAtLeast(1)

        val paragraphs = rawContent.lines().filter { it.isNotBlank() }
        val ch1Content = paragraphs.take(paragraphs.size / 2).joinToString("\n").ifBlank { rawContent }
        val ch2Content = paragraphs.drop(paragraphs.size / 2).joinToString("\n").ifBlank { rawContent }

        val newGuide = StudyGuide(
            id = "custom_${UUID.randomUUID().toString().take(8)}",
            title = title.ifBlank { "ملزمة مخصصة: $subject" },
            subject = subject.ifBlank { "مادة دراسية عامة" },
            gradeLevel = "المرحلة الدراسية الحالية",
            description = "تم استخراج ومعالجة نصوص الملزمة بنجاح. تحتوي على $wordCount كلمة مقسمة إلى فصول ومفاهيم واضحة للمذاكرة.",
            totalPages = pageCount,
            totalWords = wordCount,
            uploadDate = "الآن",
            iconType = "doc",
            chapters = listOf(
                Chapter(
                    id = "ch_cust_1",
                    title = "الفصل الأول: المفاهيم والأسس",
                    pageRange = "ص 1 - ص ${pageCount / 2 + 1}",
                    summary = ch1Content.take(150) + "...",
                    keyTerms = listOf("المفهوم الأساسي", "التعريف العلمي", "المحور الأول"),
                    fullContent = ch1Content
                ),
                Chapter(
                    id = "ch_cust_2",
                    title = "الفصل الثاني: التطبيقات والنتائج",
                    pageRange = "ص ${pageCount / 2 + 2} - ص $pageCount",
                    summary = ch2Content.take(150) + "...",
                    keyTerms = listOf("التطبيق العملي", "الاستنتاجات", "القوانين"),
                    fullContent = ch2Content
                )
            ),
            rawText = rawContent
        )

        _studyGuides.value = listOf(newGuide) + _studyGuides.value
        setActiveGuide(newGuide.id)
        _bannerStatus.value = BannerStatus.Success("تم استخراج محتوى الملزمة ومعالجتها بنجاح!")
        return newGuide
    }

    fun addChatMessage(guideId: String, message: ChatMessage) {
        val currentList = _chatMessagesMap.value[guideId] ?: emptyList()
        _chatMessagesMap.value = _chatMessagesMap.value + (guideId to (currentList + message))

        // Update daily count
        if (message.sender == SenderType.USER) {
            _dailyUsage.value = _dailyUsage.value.copy(
                questionsAskedToday = _dailyUsage.value.questionsAskedToday + 1,
                studyMinutesToday = _dailyUsage.value.studyMinutesToday + 2
            )
        }
    }

    fun startQuizSession(questionCount: Int): QuizSession {
        val session = StudyTutorEngine.createQuizSession(_activeGuide.value, questionCount)
        _currentQuizSession.value = session
        return session
    }

    fun updateQuizAnswer(questionIndex: Int, chosenKey: String) {
        val current = _currentQuizSession.value ?: return
        val updatedAnswers = current.selectedAnswers + (questionIndex to chosenKey)
        _currentQuizSession.value = current.copy(selectedAnswers = updatedAnswers)
    }

    fun submitCurrentQuiz(): QuizSession? {
        val current = _currentQuizSession.value ?: return null
        val evaluated = StudyTutorEngine.evaluateQuiz(current, _activeGuide.value, current.selectedAnswers)
        _currentQuizSession.value = evaluated
        _quizHistory.value = listOf(evaluated) + _quizHistory.value
        _dailyUsage.value = _dailyUsage.value.copy(
            quizzesTakenToday = _dailyUsage.value.quizzesTakenToday + 1,
            studyMinutesToday = _dailyUsage.value.studyMinutesToday + 5
        )
        return evaluated
    }

    fun setBanner(status: BannerStatus?) {
        _bannerStatus.value = status
    }
}
