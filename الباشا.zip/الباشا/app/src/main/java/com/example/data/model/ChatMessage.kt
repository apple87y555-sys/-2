package com.example.data.model

enum class SenderType {
    USER,
    ASSISTANT,
    SYSTEM
}

data class ChatMessage(
    val id: String,
    val guideId: String,
    val sender: SenderType,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val citedSection: String? = null,
    val isSourceConstrained: Boolean = true,
    val isWarningOrQueue: Boolean = false,
    val suggestedFollowUps: List<String> = emptyList()
)
