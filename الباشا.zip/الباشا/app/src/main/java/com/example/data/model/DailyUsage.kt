package com.example.data.model

data class DailyUsage(
    val questionsAskedToday: Int = 8,
    val maxDailyQuestions: Int = 50,
    val quizzesTakenToday: Int = 3,
    val maxDailyQuizzes: Int = 10,
    val studyMinutesToday: Int = 45,
    val isQueueBusy: Boolean = false,
    val isOfflineSimulatorActive: Boolean = true
)
