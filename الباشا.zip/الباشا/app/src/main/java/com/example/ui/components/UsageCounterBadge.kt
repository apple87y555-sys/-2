package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DailyUsage
import com.example.ui.theme.ScientificPurple
import com.example.ui.theme.ScientificPurpleContainer
import com.example.ui.theme.SmartBlue
import com.example.ui.theme.SmartBlueContainer
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfacePure
import com.example.ui.theme.TextPrimaryNavy
import com.example.ui.theme.TextSecondarySlate

@Composable
fun UsageCounterCard(
    usage: DailyUsage,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfacePure)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(16.dp))
            .padding(16.dp)
            .testTag("daily_usage_card"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = ScientificPurple,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "عداد الاستهلاك اليومي للذكاء الاصطناعي",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryNavy
                )
            }

            Text(
                text = "يتجدد يومياً",
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal,
                color = TextSecondarySlate
            )
        }

        // Progress bar for daily questions
        val progress = (usage.questionsAskedToday.toFloat() / usage.maxDailyQuestions.toFloat()).coerceIn(0f, 1f)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "استهلاك الأسئلة والاستفسارات",
                    fontSize = 12.sp,
                    color = TextSecondarySlate
                )
                Text(
                    text = "${usage.questionsAskedToday} / ${usage.maxDailyQuestions} سؤال",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SmartBlue
                )
            }
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape),
                color = SmartBlue,
                trackColor = SmartBlueContainer
            )
        }

        // 3 mini stats badges
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            UsageMetricPill(
                icon = Icons.Default.ChatBubbleOutline,
                label = "أسئلة اليوم",
                value = "${usage.questionsAskedToday} سؤال",
                containerColor = SmartBlueContainer,
                tint = SmartBlue,
                modifier = Modifier.weight(1f)
            )
            UsageMetricPill(
                icon = Icons.Default.Quiz,
                label = "الاختبارات",
                value = "${usage.quizzesTakenToday}/${usage.maxDailyQuizzes}",
                containerColor = ScientificPurpleContainer,
                tint = ScientificPurple,
                modifier = Modifier.weight(1f)
            )
            UsageMetricPill(
                icon = Icons.Default.Schedule,
                label = "وقت المذاكرة",
                value = "${usage.studyMinutesToday} دقيقة",
                containerColor = Color(0xFFF1F5F9),
                tint = TextSecondarySlate,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun UsageMetricPill(
    icon: ImageVector,
    label: String,
    value: String,
    containerColor: Color,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(containerColor)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(16.dp)
        )
        Column {
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Normal,
                color = TextSecondarySlate,
                maxLines = 1
            )
            Text(
                text = value,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryNavy,
                maxLines = 1
            )
        }
    }
}
