package com.example.ui.navigation

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.CreateQuizScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.QuizResultScreen
import com.example.ui.screens.UploadGuideScreen
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.AccentBlueContainer
import com.example.ui.theme.BackgroundCanvas
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.PrimaryDark
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.viewmodel.StudyViewModel

sealed class Screen(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    data object Home : Screen("home", "الرئيسية", Icons.Filled.Home, Icons.Outlined.Home)
    data object Library : Screen("library", "مكتبتي", Icons.AutoMirrored.Filled.MenuBook, Icons.AutoMirrored.Outlined.MenuBook)
    data object Quiz : Screen("quiz", "الاختبارات", Icons.Filled.Quiz, Icons.Outlined.Quiz)
    data object Profile : Screen("profile", "حسابي", Icons.Filled.Person, Icons.Outlined.Person)

    // Sub-screens
    data object Upload : Screen("upload", "رفع ملزمة", Icons.Filled.Home, Icons.Outlined.Home)
    data object Chat : Screen("chat", "الشات", Icons.Filled.Home, Icons.Outlined.Home)
    data object Result : Screen("result", "النتيجة", Icons.Filled.Quiz, Icons.Outlined.Quiz)
}

val bottomNavItems = listOf(
    Screen.Home,
    Screen.Library,
    Screen.Quiz,
    Screen.Profile
)

@Composable
fun AppNavigation(
    viewModel: StudyViewModel = viewModel(),
    navController: NavHostController = rememberNavController()
) {
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        viewModel.initializeWithContext(context)
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val shouldShowBottomBar = currentRoute in listOf(
        Screen.Home.route,
        Screen.Library.route,
        Screen.Quiz.route,
        Screen.Profile.route
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = BackgroundCanvas,
        bottomBar = {
            if (shouldShowBottomBar) {
                NavigationBar(
                    modifier = Modifier
                        .navigationBarsPadding()
                        .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        .border(1.dp, BorderSubtle, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        .testTag("app_bottom_bar"),
                    containerColor = SurfaceCard,
                    tonalElevation = 4.dp
                ) {
                    bottomNavItems.forEach { screen ->
                        val isSelected = currentRoute == screen.route

                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.title,
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PrimaryDark,
                                selectedTextColor = PrimaryDark,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted,
                                indicatorColor = Color(0xFFF1F5F9)
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            // 1. الرئيسية
            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateUpload = { navController.navigate(Screen.Upload.route) },
                    onNavigateChat = { navController.navigate(Screen.Chat.route) },
                    onNavigateQuiz = { navController.navigate(Screen.Quiz.route) },
                    onNavigateLibrary = { navController.navigate(Screen.Library.route) },
                    onNavigateProfile = { navController.navigate(Screen.Profile.route) }
                )
            }

            // 2. مكتبتي
            composable(Screen.Library.route) {
                LibraryScreen(
                    viewModel = viewModel,
                    onNavigateChat = { navController.navigate(Screen.Chat.route) },
                    onNavigateQuiz = { navController.navigate(Screen.Quiz.route) },
                    onNavigateUpload = { navController.navigate(Screen.Upload.route) }
                )
            }

            // 3. الاختبارات
            composable(Screen.Quiz.route) {
                CreateQuizScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onQuizSubmitted = { navController.navigate(Screen.Result.route) }
                )
            }

            // 4. حسابي
            composable(Screen.Profile.route) {
                ProfileScreen(
                    viewModel = viewModel
                )
            }

            // Sub-screens
            composable(Screen.Upload.route) {
                UploadGuideScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onUploadSuccess = { navController.navigate(Screen.Chat.route) }
                )
            }

            composable(Screen.Chat.route) {
                ChatScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Result.route) {
                QuizResultScreen(
                    viewModel = viewModel,
                    onNavigateHome = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Home.route) { inclusive = true }
                        }
                    },
                    onRetakeQuiz = {
                        viewModel.startQuiz(5)
                        navController.navigate(Screen.Quiz.route)
                    },
                    onNavigateChat = { navController.navigate(Screen.Chat.route) }
                )
            }
        }
    }
}
