package com.example.data.model

data class QuizQuestion(
    val id: String,
    val guideId: String,
    val chapterId: String,
    val chapterName: String,
    val question: String,
    val options: Map<String, String>, // "أ", "ب", "ج", "د"
    val correctAnswer: String,        // "أ" / "ب" / "ج" / "د"
    val explanation: String
)

data class QuizSession(
    val id: String,
    val guideId: String,
    val guideTitle: String,
    val totalQuestions: Int,
    val questions: List<QuizQuestion>,
    val selectedAnswers: Map<Int, String> = emptyMap(), // question index -> chosen key
    val completedTimestamp: Long = System.currentTimeMillis(),
    val score: Int = 0,
    val percentage: Int = 0,
    val motivationalMessage: String = "",
    val needReviewChapter: String? = null,
    val isCompleted: Boolean = false
)
