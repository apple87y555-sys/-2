package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = SmartBlue,
    onPrimary = Color.White,
    primaryContainer = SmartBlueContainer,
    onPrimaryContainer = SmartBlueOnContainer,
    secondary = ScientificPurple,
    onSecondary = Color.White,
    secondaryContainer = ScientificPurpleContainer,
    onSecondaryContainer = ScientificPurpleOnContainer,
    tertiary = ScientificPurpleLight,
    background = BackgroundLight,
    onBackground = TextPrimaryNavy,
    surface = SurfacePure,
    onSurface = TextPrimaryNavy,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = TextSecondarySlate,
    outline = SurfaceBorder,
    error = ErrorRed,
    onError = Color.White,
    errorContainer = ErrorRedContainer,
    onErrorContainer = ErrorRedText
)

private val DarkColorScheme = darkColorScheme(
    primary = SmartBlueLight,
    onPrimary = Color(0xFF002F6C),
    primaryContainer = SmartBlueDark,
    onPrimaryContainer = SmartBlueContainer,
    secondary = ScientificPurpleLight,
    onSecondary = Color(0xFF38006B),
    secondaryContainer = ScientificPurpleDark,
    onSecondaryContainer = ScientificPurpleContainer,
    tertiary = SmartBlue,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = Color(0xFF475569),
    error = ErrorRed,
    onError = Color.White,
    errorContainer = Color(0xFF450A0A),
    onErrorContainer = Color(0xFFFCA5A5)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
