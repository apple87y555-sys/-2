package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.QuizQuestion
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.AccentBlueContainer
import com.example.ui.theme.BackgroundCanvas
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.PrimaryDark
import com.example.ui.theme.PrimaryOnDark
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorContainer
import com.example.ui.theme.StatusErrorText
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.StatusSuccessText
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSubtle
import com.example.ui.viewmodel.StudyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizResultScreen(
    viewModel: StudyViewModel,
    onNavigateHome: () -> Unit,
    onRetakeQuiz: () -> Unit,
    onNavigateChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeGuide by viewModel.activeGuide.collectAsStateWithLifecycle()
    val currentSession by viewModel.currentQuizSession.collectAsStateWithLifecycle()

    val session = currentSession ?: run {
        Box(
            modifier = Modifier.fillMaxSize().background(BackgroundCanvas),
            contentAlignment = Alignment.Center
        ) {
            Button(onClick = onNavigateHome) { Text("العودة للرئيسية") }
        }
        return
    }

    val scorePercentage = session.percentage
    val performancePraise = when {
        scorePercentage >= 90 -> "أداء استثنائي رائع! 🏆"
        scorePercentage >= 75 -> "أداء رائع ومتميز! 👏"
        scorePercentage >= 60 -> "أداء جيد، مع فرصة للمراجعة 👍"
        else -> "تحتاج لمراجعة أعمق للملزمة 💪"
    }

    val incorrectQuestions = session.questions.filterIndexed { index, q ->
        val chosen = session.selectedAnswers[index]
        chosen != null && chosen != q.correctAnswer
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("quiz_result_screen"),
        containerColor = BackgroundCanvas,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "نتيجة الاختبار",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMain
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateHome,
                        modifier = Modifier.testTag("back_from_result_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "الرئيسية",
                            tint = PrimaryDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceCard)
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // إعادة الاختبار
                    OutlinedButton(
                        onClick = onRetakeQuiz,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("retake_quiz_button"),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Replay, contentDescription = null, tint = PrimaryDark, modifier = Modifier.size(16.dp))
                            Text("إعادة الاختبار", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PrimaryDark)
                        }
                    }

                    // مراجعة الأخطاء في الشات
                    Button(
                        onClick = {
                            viewModel.discussMistakesInChat()
                            onNavigateChat()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("discuss_mistakes_in_chat_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryDark)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Text("مراجعة الأخطاء", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PrimaryOnDark)
                        }
                    }
                }

                // العودة للرئيسية
                Button(
                    onClick = onNavigateHome,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("return_home_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9))
                ) {
                    Text("العودة للرئيسية", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PrimaryDark)
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ثامنًا: نتيجة الاختبار الرئيسية (8 / 10 + نسبة النجاح + أداء رائع)
            item {
                HeroResultCard(
                    correctCount = session.score,
                    totalQuestions = session.totalQuestions,
                    scorePercentage = scorePercentage,
                    praiseText = performancePraise,
                    guideTitle = activeGuide.title
                )
            }

            // تحليل مختصر (نقاط القوة + الموضوعات التي تحتاج مراجعة)
            item {
                BriefAnalysisSection(
                    correctCount = session.score,
                    incorrectQuestions = incorrectQuestions
                )
            }

            // مراجعة تفصيلية للأسئلة
            item {
                Text(
                    text = "مراجعة جميع الأسئلة (${session.questions.size}):",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMain
                )
            }

            itemsIndexed(session.questions) { index, question ->
                val chosen = session.selectedAnswers[index]
                DetailedQuestionReviewItem(
                    index = index + 1,
                    question = question,
                    chosenKey = chosen
                )
            }
        }
    }
}

@Composable
private fun HeroResultCard(
    correctCount: Int,
    totalQuestions: Int,
    scorePercentage: Int,
    praiseText: String,
    guideTitle: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(SurfaceCard)
            .border(1.dp, BorderSubtle, RoundedCornerShape(20.dp))
            .padding(24.dp)
            .testTag("hero_result_card")
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = guideTitle,
                fontSize = 12.sp,
                color = TextMuted,
                maxLines = 1
            )

            // 8 / 10
            Text(
                text = "$correctCount / $totalQuestions",
                fontSize = 38.sp,
                fontWeight = FontWeight.Bold,
                color = PrimaryDark
            )

            // Percentage Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (scorePercentage >= 75) StatusSuccessContainer else AccentBlueContainer)
                    .padding(horizontal = 14.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "نسبة النجاح: $scorePercentage%",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (scorePercentage >= 75) StatusSuccess else AccentBlue
                )
            }

            Text(
                text = praiseText,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextMain,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun BriefAnalysisSection(
    correctCount: Int,
    incorrectQuestions: List<QuizQuestion>
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceCard)
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .padding(18.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                text = "التحليل الأكاديمي للأداء:",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextMain
            )

            // نقاط القوة
            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(StatusSuccessContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = StatusSuccess,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "نقاط القوة ($correctCount أسئلة متقنة)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = StatusSuccessText
                    )
                    Text(
                        text = "إتقان ممتاز للمفاهيم والتعريفات الأساسية والقدرة على الاسترجاع المباشر.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }
            }

            // موضوعات تحتاج مراجعة
            if (incorrectQuestions.isNotEmpty()) {
                Row(
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(StatusErrorContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = StatusError,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "موضوعات تحتاج مراجعة (${incorrectQuestions.size} أسئلة)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusErrorText
                        )
                        Text(
                            text = "يُنصح بمراجعة فصول: " + incorrectQuestions.map { it.chapterName }.distinct().joinToString(" ، "),
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailedQuestionReviewItem(
    index: Int,
    question: QuizQuestion,
    chosenKey: String?
) {
    val isCorrect = chosenKey == question.correctAnswer

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceCard)
            .border(
                1.dp,
                if (isCorrect) StatusSuccessContainer else StatusErrorContainer,
                RoundedCornerShape(14.dp)
            )
            .padding(14.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(if (isCorrect) StatusSuccessContainer else StatusErrorContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isCorrect) Icons.Default.Check else Icons.Default.Close,
                        contentDescription = null,
                        tint = if (isCorrect) StatusSuccess else StatusError,
                        modifier = Modifier.size(14.dp)
                    )
                }

                Text(
                    text = "سؤال $index: ${question.question}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMain,
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = "الإجابة الصحيحة: (${question.correctAnswer}) " + (question.options[question.correctAnswer] ?: ""),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = StatusSuccessText
            )

            if (!isCorrect && chosenKey != null) {
                Text(
                    text = "إجابتك: ($chosenKey) " + (question.options[chosenKey] ?: ""),
                    fontSize = 12.sp,
                    color = StatusErrorText
                )
            }

            Text(
                text = "التفسير: ${question.explanation}",
                fontSize = 11.sp,
                color = TextMuted
            )
        }
    }
}
