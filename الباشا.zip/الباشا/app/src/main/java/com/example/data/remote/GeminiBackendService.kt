package com.example.data.remote

import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class GeminiUploadState {
    data object Idle : GeminiUploadState()
    data class Uploading(val progress: Float = 0.5f) : GeminiUploadState()
    data class Success(val fileUri: String, val fileName: String) : GeminiUploadState()
    data class Error(val message: String) : GeminiUploadState()
}

sealed class GeminiQueryResult {
    data class Success(val answer: String, val source: String = "Gemini 3.5 Flash (الملزمة المرفوعة)") : GeminiQueryResult()
    data class ConnectionError(val message: String) : GeminiQueryResult()
    data class GeneralError(val message: String) : GeminiQueryResult()
}

object GeminiBackendService {

    private const val BASE_URL = "https://generativelanguage.googleapis.com"
    private const val MODEL_NAME = "gemini-3.5-flash"

    const val OUT_OF_SCOPE_STANDARD_ANSWER =
        "عذرًا، هذه المعلومة غير متوفرة في الملزمة المرفوعة. أسئلتي مقتطعة من محتوى المادة فقط لضمان دقة معلوماتك."

    const val SYSTEM_PROMPT = """# System Prompt — تطبيق زاكرلي

أنت المساعد الذكي لتطبيق "زاكرلي" للطلاب. مهمتك مساعدة الطالب على فهم ملزمة دراسية محددة تم رفعها، من خلال الإجابة على أسئلته وتوليد اختبارات (MCQ) منها.

## المصدر الوحيد للمعلومات
- اعتمد حصريًا على محتوى الملزمة المرفوعة المرفقة لك في هذه المحادثة.
- إذا كان السؤال يتعلق بمعلومات غير موجودة في الملزمة، أو يسأل عن مواضيع خارجية، يجب عليك الرد حرفيًا بالنص التالي فقط دون أي زيادة أو نقصان:
"$OUT_OF_SCOPE_STANDARD_ANSWER"
- لا تخمن أو تستنتج معلومات غير موجودة في الملزمة حتى لو كانت صحيحة علمياً.
- التزم بالدقة والأمانة الأكاديمية واللغة العربية الفصحى الواضحة والمنسقة."""

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun getApiKey(): String {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isNullOrBlank() || key == "MY_GEMINI_API_KEY") "" else key
        } catch (_: Exception) {
            ""
        }
    }

    fun isApiKeyConfigured(): Boolean {
        val key = getApiKey()
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }

    /**
     * Uploads a PDF file directly to the Gemini Files API.
     * Endpoint: POST https://generativelanguage.googleapis.com/upload/v1beta/files
     */
    suspend fun uploadPdfFile(pdfFile: File, displayName: String): GeminiUploadState = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext GeminiUploadState.Error("لم يتم ضبط مفتاح Gemini API في متغيرات البيئة (Secrets).")
        }

        try {
            val mediaType = "application/pdf".toMediaType()
            val requestBody = pdfFile.asRequestBody(mediaType)

            val url = "$BASE_URL/upload/v1beta/files?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .addHeader("X-Goog-Upload-Command", "start, upload, finalize")
                .addHeader("X-Goog-Upload-Header-Content-Length", pdfFile.length().toString())
                .addHeader("X-Goog-Upload-Header-Content-Type", "application/pdf")
                .addHeader("X-Goog-Upload-Protocol", "resumable")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext GeminiUploadState.Error(
                    "فشل الرفع إلى Gemini Files API (${response.code}): ${response.message}"
                )
            }

            val json = JSONObject(responseBody)
            val fileObj = json.optJSONObject("file")
            val fileUri = fileObj?.optString("uri") ?: ""
            val fileName = fileObj?.optString("name") ?: ""

            if (fileUri.isNotBlank()) {
                GeminiUploadState.Success(fileUri = fileUri, fileName = fileName)
            } else {
                GeminiUploadState.Error("استجابة غير مكتملة من Gemini Files API.")
            }
        } catch (e: IOException) {
            GeminiUploadState.Error("فشل الاتصال بخادم Gemini أثناء رفع الملف: ${e.localizedMessage}")
        } catch (e: Exception) {
            GeminiUploadState.Error("خطأ غير متوقع أثناء الرفع: ${e.localizedMessage}")
        }
    }

    /**
     * Sends user question and linked study guide PDF to Gemini 3.5 Flash.
     */
    suspend fun askGemini(
        geminiFileUri: String?,
        localPdfFile: File?,
        rawTextContent: String?,
        studentQuestion: String
    ): GeminiQueryResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext GeminiQueryResult.GeneralError("مفتاح Gemini API غير مهيأ.")
        }

        try {
            val partsArray = JSONArray()

            // 1. Attach File (either by Gemini File URI or Inline base64 or Extracted Text)
            if (!geminiFileUri.isNullOrBlank()) {
                val fileDataObj = JSONObject().apply {
                    put("mimeType", "application/pdf")
                    put("fileUri", geminiFileUri)
                }
                val filePart = JSONObject().apply {
                    put("fileData", fileDataObj)
                }
                partsArray.put(filePart)
            } else if (localPdfFile != null && localPdfFile.exists() && localPdfFile.length() < 15 * 1024 * 1024) {
                val fileBytes = localPdfFile.readBytes()
                val base64Data = Base64.encodeToString(fileBytes, Base64.NO_WRAP)
                val inlineDataObj = JSONObject().apply {
                    put("mimeType", "application/pdf")
                    put("data", base64Data)
                }
                val inlinePart = JSONObject().apply {
                    put("inlineData", inlineDataObj)
                }
                partsArray.put(inlinePart)
            } else if (!rawTextContent.isNullOrBlank()) {
                val contextPart = JSONObject().apply {
                    put("text", "محتوى الملزمة الدراسية المرفوعة:\n\n$rawTextContent")
                }
                partsArray.put(contextPart)
            }

            // 2. Attach Student Question
            val questionPart = JSONObject().apply {
                put("text", "سؤال الطالب: $studentQuestion")
            }
            partsArray.put(questionPart)

            // 3. Build Full Request Body
            val contentObj = JSONObject().apply {
                put("role", "user")
                put("parts", partsArray)
            }

            val systemInstructionObj = JSONObject().apply {
                val sysParts = JSONArray().apply {
                    put(JSONObject().apply { put("text", SYSTEM_PROMPT) })
                }
                put("parts", sysParts)
            }

            val genConfigObj = JSONObject().apply {
                put("temperature", 0.2)
                put("topP", 0.95)
            }

            val requestJson = JSONObject().apply {
                put("contents", JSONArray().apply { put(contentObj) })
                put("systemInstruction", systemInstructionObj)
                put("generationConfig", genConfigObj)
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = requestJson.toString().toRequestBody(mediaType)

            val url = "$BASE_URL/v1beta/models/$MODEL_NAME:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext GeminiQueryResult.GeneralError(
                    "فشل طلب Gemini (${response.code}): ${response.message}"
                )
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text")

            if (!text.isNullOrBlank()) {
                GeminiQueryResult.Success(answer = text.trim())
            } else {
                GeminiQueryResult.GeneralError("لم يتم استلام نص استجابة من Gemini.")
            }
        } catch (e: IOException) {
            GeminiQueryResult.ConnectionError("انقطاع الاتصال بخدمة الذكاء الاصطناعي: ${e.localizedMessage}")
        } catch (e: Exception) {
            GeminiQueryResult.GeneralError("حدث خطأ أثناء معالجة السؤال: ${e.localizedMessage}")
        }
    }
}
