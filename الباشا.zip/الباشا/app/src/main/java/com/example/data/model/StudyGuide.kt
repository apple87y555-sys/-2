package com.example.data.model

data class Chapter(
    val id: String,
    val title: String,
    val pageRange: String,
    val summary: String,
    val keyTerms: List<String>,
    val fullContent: String
)

data class StudyGuide(
    val id: String,
    val title: String,
    val subject: String,
    val gradeLevel: String,
    val description: String,
    val totalPages: Int,
    val totalWords: Int,
    val chapters: List<Chapter>,
    val rawText: String,
    val uploadDate: String,
    val iconType: String,
    val isDefault: Boolean = false,
    val geminiFileUri: String? = null,
    val geminiFileId: String? = null,
    val localPdfPath: String? = null
)
