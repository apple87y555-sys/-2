package com.example.data.local

import com.example.data.model.Chapter
import com.example.data.model.ChatMessage
import com.example.data.model.QuizQuestion
import com.example.data.model.QuizSession
import com.example.data.model.SenderType
import com.example.data.model.StudyGuide
import java.util.UUID

object StudyTutorEngine {

    const val OUT_OF_SCOPE_RESPONSE = "عذرًا، هذه المعلومة غير متوفرة في الملزمة المرفوعة. أسئلتي مقتطعة من محتوى المادة فقط لضمان دقة معلوماتك."

    /**
     * Answers the student's question based strictly on the provided study guide.
     */
    fun answerStudentQuestion(guide: StudyGuide, userQuery: String): ChatMessage {
        val cleanQuery = userQuery.trim().lowercase()

        // Check if query matches quick prompt triggers
        when {
            cleanQuery.contains("لخص لي المفهوم الرئيسي") || cleanQuery.contains("ملخص عام") || cleanQuery.contains("لخص الملزمة") -> {
                val summaryBullets = guide.chapters.joinToString("\n") { chapter ->
                    "• **${chapter.title}** (${chapter.pageRange}): ${chapter.summary}"
                }
                val responseText = """
مرحبًا بك يا بطل! إليك ملخص المفاهيم الرئيسية المذكورة في ملزمة "${guide.title}":

$summaryBullets

💡 *نصيحة للمذاكرة: ركّز على المفاهيم المذكورة في الفصول المتتالية لتثبيت الفهم بشكل تدريجي.*
                """.trimIndent()
                return ChatMessage(
                    id = UUID.randomUUID().toString(),
                    guideId = guide.id,
                    sender = SenderType.ASSISTANT,
                    text = responseText,
                    citedSection = "ملخص شامل لجميع فصول الملزمة",
                    suggestedFollowUps = listOf("اشرح لي الفصل الأول بالتفصيل", "أهم القوانين والتعريفات", "أنشئ لي اختبارًا تجريبيًا")
                )
            }

            cleanQuery.contains("اشرح لي الصفحة الأخيرة") || cleanQuery.contains("الفصل الأخير") || cleanQuery.contains("نهاية الملزمة") -> {
                val lastChapter = guide.chapters.lastOrNull()
                if (lastChapter != null) {
                    val responseText = """
بناءً على ${lastChapter.title} (${lastChapter.pageRange}):

${lastChapter.summary}

**النقاط الأساسية المذكورة في هذا الجزء:**
${lastChapter.keyTerms.joinToString("\n") { term -> "• **$term**: مبيّن في نصوص هذا الفصل." }}
                    """.trimIndent()
                    return ChatMessage(
                        id = UUID.randomUUID().toString(),
                        guideId = guide.id,
                        sender = SenderType.ASSISTANT,
                        text = responseText,
                        citedSection = "${lastChapter.title} - ${lastChapter.pageRange}",
                        suggestedFollowUps = listOf("ما هي أهم الأسئلة على هذا الفصل؟", "لخص الفصل السابق")
                    )
                }
            }

            cleanQuery.contains("أهم القوانين والتعريفات") || cleanQuery.contains("التعريفات") || cleanQuery.contains("المصطلحات") -> {
                val allTerms = guide.chapters.flatMap { ch -> ch.keyTerms.map { term -> "• **$term** (مذكور في ${ch.title})" } }
                val responseText = """
أهم المصطلحات والتعريفات الواردة في ملزمة "${guide.title}":

${allTerms.take(8).joinToString("\n")}

هل تود شرح أي من هذه المفاهيم بشكل مبسط؟
                """.trimIndent()
                return ChatMessage(
                    id = UUID.randomUUID().toString(),
                    guideId = guide.id,
                    sender = SenderType.ASSISTANT,
                    text = responseText,
                    citedSection = "مقتطف من قائمة المصطلحات بجميع الفصول",
                    suggestedFollowUps = listOf("اشرح لي المصطلح الأول", "اختبرني في هذه التعريفات")
                )
            }

            cleanQuery.contains("النقاط الصعبة") || cleanQuery.contains("أهم الأسئلة المتوقعة") -> {
                val responseText = """
بناءً على موضوعات ملزمة "${guide.title}"، إليك أهم النقاط التي تتطلب تركيزًا دقيقًا:

1. **التمييز بين المفاهيم المتقاربة:** انتبه للفروق الجوهرية الموضحة في مقارنات الفصول.
2. **التسلسل والترتيب المنطقي:** راجع المراحل والأطوار بدقة بالترتيب الزمني الصحيح.
3. **العلاقات والنتائج المترتبة:** تأكد من فهم أسباب ونتائج القوانين والظواهر المذكورة.

هل تحب أن نبدأ بحل أسئلة تدريبية عليها الآن؟
                """.trimIndent()
                return ChatMessage(
                    id = UUID.randomUUID().toString(),
                    guideId = guide.id,
                    sender = SenderType.ASSISTANT,
                    text = responseText,
                    citedSection = "دليل المذاكرة المركزة للملزمة",
                    suggestedFollowUps = listOf("ابدأ اختبارًا سريعًا", "اشرح لي بالتفصيل")
                )
            }
        }

        // Search for relevant chapter or content snippet inside the study guide
        val matchingChapter = findRelevantChapter(guide, cleanQuery)

        if (matchingChapter != null) {
            val responseText = generateFriendlyExplanation(guide, matchingChapter, cleanQuery)
            return ChatMessage(
                id = UUID.randomUUID().toString(),
                guideId = guide.id,
                sender = SenderType.ASSISTANT,
                text = responseText,
                citedSection = "بناءً على ${matchingChapter.title} (${matchingChapter.pageRange})",
                suggestedFollowUps = listOf(
                    "اشرح أكثر عن هذه النقطة",
                    "اختبرني في هذا الموضوع",
                    "ما هي التطبيقات العملية المذكورة؟"
                )
            )
        }

        // If completely out of the booklet context, strictly return the required out-of-scope sentence
        return ChatMessage(
            id = UUID.randomUUID().toString(),
            guideId = guide.id,
            sender = SenderType.ASSISTANT,
            text = OUT_OF_SCOPE_RESPONSE,
            citedSection = null,
            isSourceConstrained = true,
            suggestedFollowUps = listOf(
                "ما هي محتويات هذه الملزمة؟",
                "لخص لي المفهوم الرئيسي",
                "أهم القوانين والتعريفات"
            )
        )
    }

    private fun findRelevantChapter(guide: StudyGuide, query: String): Chapter? {
        val stopWords = setOf("ما", "هي", "هو", "كم", "عدد", "في", "من", "عن", "على", "إلى", "مع", "هل", "أين", "كيف", "لماذا", "ماذا", "هذا", "هذه")
        val words = query.split(Regex("[\\s,?.!؟]+"))
            .map { it.trim().lowercase() }
            .filter { it.length >= 3 && !stopWords.contains(it) }

        if (words.isEmpty()) return null

        // 1. Direct key terms matching (exact or stemmed)
        for (ch in guide.chapters) {
            for (term in ch.keyTerms) {
                val cleanTerm = term.trim().lowercase()
                if (cleanTerm.isNotEmpty() && query.contains(cleanTerm)) {
                    return ch
                }
                for (w in words) {
                    if (cleanTerm.length >= 3 && (w == cleanTerm || cleanTerm.split(" ").contains(w))) {
                        return ch
                    }
                }
            }
        }

        // 2. Search in chapter title or full content for significant academic keywords
        for (ch in guide.chapters) {
            val titleClean = ch.title.lowercase()
            if (words.any { w -> titleClean.contains(w) }) {
                return ch
            }

            // Must match at least 2 distinct query words in the text, or a specific multi-letter term
            val matches = words.count { w -> ch.fullContent.lowercase().contains(w) }
            if (matches >= 2 || (words.size == 1 && ch.fullContent.lowercase().contains(words.first()))) {
                return ch
            }
        }

        return null
    }

    private fun generateFriendlyExplanation(guide: StudyGuide, chapter: Chapter, query: String): String {
        val lines = chapter.fullContent.lines().filter { it.isNotBlank() && !it.startsWith("الفصل") }
        val relevantSnippet = lines.firstOrNull { line ->
            query.split(" ").any { w -> w.length > 2 && line.contains(w) }
        } ?: lines.take(3).joinToString("\n")

        return """
أهلاً بك! بناءً على ${chapter.title} (${chapter.pageRange}) من ملزمتك:

$relevantSnippet

📌 **خلاصة مبسطة:**
${chapter.summary}

إذا كنت بحاجة إلى تفصيل أكثر أو أمثلة إضافية من الملزمة، فقط أخبرني وسأشرحها لك خطوة بخطوة! ✨
        """.trimIndent()
    }

    /**
     * Generates a structured quiz session for the given guide and question count.
     */
    fun createQuizSession(guide: StudyGuide, questionCount: Int): QuizSession {
        val baseQuestions = SampleStudyGuides.getQuestionsForGuide(guide.id)
        val selectedQuestions = if (baseQuestions.size >= questionCount) {
            baseQuestions.take(questionCount)
        } else {
            // Expand by generating from chapters if more questions are requested
            val result = mutableListOf<QuizQuestion>()
            result.addAll(baseQuestions)
            var counter = result.size + 1
            for (ch in guide.chapters) {
                if (result.size >= questionCount) break
                for (term in ch.keyTerms) {
                    if (result.size >= questionCount) break
                    result.add(
                        QuizQuestion(
                            id = "gen_${guide.id}_$counter",
                            guideId = guide.id,
                            chapterId = ch.id,
                            chapterName = ch.title,
                            question = "أيٌّ مما يلي يُعد من الخصائص الأساسية المرتبطة بـ ($term) وفقاً لما ورد في الملزمة؟",
                            options = mapOf(
                                "أ" to "يمثل عنصراً محورياً تم تناوله في نصوص ${ch.title}.",
                                "ب" to "ظاهرة خارجية غير مشمولة في نطاق هذا الفصل.",
                                "ج" to "مفهوم معاكس تماماً للعمليات الحيوية المذكورة.",
                                "د" to "معلومة ملغاة من المقرر الدراسي."
                            ),
                            correctAnswer = "أ",
                            explanation = "الشرح: بناءً على ${ch.title} (${ch.pageRange})، يُعد ($term) من الركائز الأساسية التي تستند إليها محاور المذاكرة الموضحة بالملزمة."
                        )
                    )
                    counter++
                }
            }
            result.take(questionCount)
        }

        return QuizSession(
            id = UUID.randomUUID().toString(),
            guideId = guide.id,
            guideTitle = guide.title,
            totalQuestions = selectedQuestions.size,
            questions = selectedQuestions
        )
    }

    /**
     * Evaluates a completed quiz session and creates the motivational performance report.
     * Respects the required format:
     * - Short motivational message (max 2 lines).
     * - Positive feedback matching score (ممتاز / جيد / يحتاج مراجعة).
     * - Specific recommendation to review chapter where errors occurred.
     */
    fun evaluateQuiz(session: QuizSession, guide: StudyGuide, answers: Map<Int, String>): QuizSession {
        var correctCount = 0
        val wrongChapters = mutableMapOf<String, Int>()

        session.questions.forEachIndexed { index, question ->
            val chosen = answers[index]
            if (chosen != null && chosen.trim() == question.correctAnswer.trim()) {
                correctCount++
            } else {
                wrongChapters[question.chapterName] = (wrongChapters[question.chapterName] ?: 0) + 1
            }
        }

        val total = session.questions.size
        val percentage = if (total > 0) ((correctCount.toDouble() / total) * 100).toInt() else 0

        val mostMissedChapter = wrongChapters.maxByOrNull { it.value }?.key

        val motivationalMessage = when {
            percentage >= 90 -> {
                if (mostMissedChapter != null) {
                    "أداء استثنائي رائع ومبهر! لقد أتقنت معظم محتويات الملزمة بجدارة، ولتحقيق الدرجة الكاملة راجع سريعًا موضوع [$mostMissedChapter]."
                } else {
                    "أداء ممتاز ومتقن بنسبة 100%! أظهرت تفوقًا واستيعابًا كاملاً لجميع أجزاء الملزمة، واصل هذا التميز!"
                }
            }
            percentage >= 70 -> {
                val targetChapter = mostMissedChapter ?: guide.chapters.firstOrNull()?.title ?: "الفصل الثاني"
                "أداء رائع! أظهرت تفوقًا في المفاهيم العامة، ننصحك بإعادة قراءة القسم الخاص بـ [$targetChapter] لتعزيز درجاتك."
            }
            percentage >= 50 -> {
                val targetChapter = mostMissedChapter ?: guide.chapters.firstOrNull()?.title ?: "الفصل الأول"
                "جهد جيد وبداية موفقة للمذاكرة! يُفضل تخصيص وقت لمراجعة [$targetChapter] وحل الأسئلة مرة أخرى لرفع كفاءتك."
            }
            else -> {
                val targetChapter = mostMissedChapter ?: guide.chapters.firstOrNull()?.title ?: "المفاهيم الأساسية"
                "لا تقلق، الاختبار فرصة مثالية للتعلّم! ننصحك بقراءة [$targetChapter] بعناية في الملزمة ثم إعادة المحاولة."
            }
        }

        return session.copy(
            selectedAnswers = answers,
            score = correctCount,
            percentage = percentage,
            motivationalMessage = motivationalMessage,
            needReviewChapter = mostMissedChapter,
            isCompleted = true,
            completedTimestamp = System.currentTimeMillis()
        )
    }
}
