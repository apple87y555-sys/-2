package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.PdfGuideManager
import com.example.data.local.PdfMetadata
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.AccentBlueContainer
import com.example.ui.theme.BackgroundCanvas
import com.example.ui.theme.BorderMedium
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.PrimaryDark
import com.example.ui.theme.PrimaryOnDark
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorContainer
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSubtle
import com.example.ui.viewmodel.StudyViewModel
import com.example.ui.viewmodel.UploadUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadGuideScreen(
    viewModel: StudyViewModel,
    onNavigateBack: () -> Unit,
    onUploadSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uploadState by viewModel.uploadState.collectAsStateWithLifecycle()

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedMetadata by remember { mutableStateOf<PdfMetadata?>(null) }
    var customSubject by remember { mutableStateOf("") }

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            selectedMetadata = PdfGuideManager.inspectUriMetadata(context, uri)
            viewModel.resetUploadState()
        }
    }

    val isProcessing = uploadState is UploadUiState.Processing

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("upload_guide_screen"),
        containerColor = BackgroundCanvas,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "رفع ملزمة جديدة",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMain
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("back_from_upload_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "رجوع",
                            tint = PrimaryDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceCard)
            )
        },
        bottomBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .padding(horizontal = 20.dp, vertical = 14.dp)
                    .navigationBarsPadding()
            ) {
                Button(
                    onClick = {
                        val uri = selectedUri
                        if (uri != null && !isProcessing) {
                            viewModel.uploadPdfFile(
                                context = context,
                                uri = uri,
                                customSubject = customSubject.ifBlank { null }
                            )
                        }
                    },
                    enabled = selectedUri != null && !isProcessing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("start_analysis_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryDark,
                        disabledContainerColor = Color(0xFFE2E8F0)
                    )
                ) {
                    if (isProcessing) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "جاري التحليل والمعالجة...",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    } else {
                        Text(
                            text = "بدء التحليل",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryOnDark
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // منطقة كبيرة لاختيار الملف (Large Drop / Pick Area)
            item {
                if (selectedUri == null) {
                    EmptyUploadZone(
                        onPickFile = { pdfPickerLauncher.launch("application/pdf") }
                    )
                } else {
                    SelectedFileCard(
                        metadata = selectedMetadata,
                        onDelete = {
                            selectedUri = null
                            selectedMetadata = null
                            viewModel.resetUploadState()
                        },
                        onChangeFile = { pdfPickerLauncher.launch("application/pdf") }
                    )
                }
            }

            // إظهار الحد المسموح للملف
            item {
                FileLimitsNotice()
            }

            // Subject / Title Customization (Optional)
            if (selectedUri != null) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "المادة الدراسية (اختياري)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextMain
                        )
                        OutlinedTextField(
                            value = customSubject,
                            onValueChange = { customSubject = it },
                            placeholder = {
                                Text(
                                    text = "مثال: الأحياء، الفيزياء، الرياضيات...",
                                    fontSize = 13.sp,
                                    color = TextMuted
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("custom_subject_field"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AccentBlue,
                                unfocusedBorderColor = BorderSubtle,
                                focusedContainerColor = SurfaceCard,
                                unfocusedContainerColor = SurfaceCard
                            ),
                            singleLine = true
                        )
                    }
                }
            }

            // Processing Progress & Steps
            if (uploadState is UploadUiState.Processing) {
                val state = uploadState as UploadUiState.Processing
                item {
                    ProcessingProgressCard(
                        stepMessage = state.step,
                        progress = state.progress
                    )
                }
            }

            // Success State Card
            if (uploadState is UploadUiState.Success) {
                val success = uploadState as UploadUiState.Success
                item {
                    UploadSuccessCard(
                        message = success.message,
                        guideTitle = success.guide.title,
                        onProceedToChat = onUploadSuccess
                    )
                }
            }

            // Error State Card
            if (uploadState is UploadUiState.Error) {
                val error = uploadState as UploadUiState.Error
                item {
                    UploadErrorCard(
                        errorMessage = error.message,
                        onRetry = {
                            selectedUri?.let {
                                viewModel.uploadPdfFile(context, it, customSubject.ifBlank { null })
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyUploadZone(
    onPickFile: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(SurfaceCard)
            .border(1.5.dp, BorderMedium, RoundedCornerShape(20.dp))
            .clickable { onPickFile() }
            .padding(vertical = 36.dp, horizontal = 20.dp)
            .testTag("file_picker_drop_zone"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(AccentBlueContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CloudUpload,
                    contentDescription = null,
                    tint = AccentBlue,
                    modifier = Modifier.size(32.dp)
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "اختر PDF من هاتفك",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMain
                )
                Text(
                    text = "اضغط هنا لتصفح واختيار ملف الملزمة الدراسية",
                    fontSize = 13.sp,
                    color = TextMuted
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(PrimaryDark)
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text(
                    text = "تصفح الملفات",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryOnDark
                )
            }
        }
    }
}

@Composable
private fun SelectedFileCard(
    metadata: PdfMetadata?,
    onDelete: () -> Unit,
    onChangeFile: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(SurfaceCard)
            .border(1.dp, BorderSubtle, RoundedCornerShape(18.dp))
            .padding(18.dp)
            .testTag("selected_file_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(AccentBlueContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Description,
                    contentDescription = null,
                    tint = AccentBlue,
                    modifier = Modifier.size(26.dp)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = metadata?.fileName ?: "ملزمة.pdf",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMain,
                    maxLines = 1
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = metadata?.sizeFormatted ?: "جاهز للمعالجة",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Text(
                        text = "•",
                        fontSize = 12.sp,
                        color = TextSubtle
                    )
                    Text(
                        text = "PDF",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentBlue
                    )
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFEF2F2))
                    .testTag("delete_selected_file_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "حذف الملف",
                    tint = StatusError,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun FileLimitsNotice() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFF8FAFC))
            .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(18.dp).padding(top = 2.dp)
            )
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = "شروط وحدود رفع الملفات المعتمدة:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMain
                )
                Text(
                    text = "• الصيغة المسموحة: ملفات PDF فقط.\n• الحد الأقصى للحجم: 20 ميجابايت.\n• الحد الأقصى للصفحات: 30 صفحة لكل ملزمة لضمان سرعة الفهرسة.",
                    fontSize = 11.sp,
                    color = TextMuted,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
private fun ProcessingProgressCard(
    stepMessage: String,
    progress: Float
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceCard)
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .padding(16.dp)
            .testTag("processing_progress_card")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stepMessage,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMain
                )
                Text(
                    text = "${(progress * 100).toInt()}%",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentBlue
                )
            }

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = AccentBlue,
                trackColor = BorderSubtle,
                strokeCap = StrokeCap.Round
            )
        }
    }
}

@Composable
private fun UploadSuccessCard(
    message: String,
    guideTitle: String,
    onProceedToChat: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(StatusSuccessContainer)
            .border(1.dp, StatusSuccess.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            .padding(18.dp)
            .testTag("upload_success_card")
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = StatusSuccess,
                modifier = Modifier.size(36.dp)
            )

            Text(
                text = "تم الرفع والتحليل بنجاح!",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = StatusSuccess
            )

            Text(
                text = message,
                fontSize = 13.sp,
                color = TextMuted,
                textAlign = TextAlign.Center
            )

            Button(
                onClick = onProceedToChat,
                modifier = Modifier.fillMaxWidth().height(46.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryDark)
            ) {
                Text(
                    text = "فتح شات الملزمة الآن",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryOnDark
                )
            }
        }
    }
}

@Composable
private fun UploadErrorCard(
    errorMessage: String,
    onRetry: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(StatusErrorContainer)
            .border(1.dp, StatusError.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            .padding(16.dp)
            .testTag("upload_error_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Error,
                contentDescription = null,
                tint = StatusError,
                modifier = Modifier.size(24.dp)
            )

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = "فشل في معالجة الملف",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = StatusError
                )
                Text(
                    text = errorMessage,
                    fontSize = 12.sp,
                    color = TextMuted
                )
            }

            Button(
                onClick = onRetry,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = StatusError)
            ) {
                Text(text = "إعادة", fontSize = 12.sp, color = Color.White)
            }
        }
    }
}
