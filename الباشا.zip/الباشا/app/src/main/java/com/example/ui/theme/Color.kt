package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// =========================================================================
// لوحة الهوية البصرية لتطبيق "زاكرلي" (خلفية رمادية هادئة ومريحة للعين)
// =========================================================================

// اللون الأساسي الداكن الأنيق للعناوين والأزرار والبطاقات الرئيسية
val PrimaryDark = Color(0xFF0F172A)          // كحلي داكن فاخر وعالي التباين (Slate 900)
val PrimaryDarkHover = Color(0xFF1E293B)     // Slate 800
val PrimaryDarkContainer = Color(0xFFE2E8F0) // رمادي محايد
val PrimaryOnDark = Color(0xFFFFFFFF)

// اللون المميز الهادئ للتفاعلات والأيقونات والروابط (Smart Blue Accent)
val AccentBlue = Color(0xFF2563EB)           // أزرق تعليمي احترافي (Blue 600)
val AccentBlueLight = Color(0xFF3B82F6)      // Blue 500
val AccentBlueContainer = Color(0xFFEFF6FF)  // Blue 50
val AccentBlueOnContainer = Color(0xFF1D4ED8)

// اللون الثانوي الهادئ للوسوم والبطاقات الفرعية
val SecondarySlate = Color(0xFF334155)       // Slate 700
val SecondarySlateLight = Color(0xFF475569)  // Slate 600
val SecondarySlateContainer = Color(0xFFE2E8F0) // Slate 200

// خلفيات الشاشات والأسطح (استبدال الأبيض الساطع برمادي فاتح مريح للعين)
val BackgroundCanvas = Color(0xFFF5F5F5)     // رمادي فاتح مريح للعين يقلل الإجهاد البصري (Slate 100)
val SurfaceCard = Color(0xFFFFFFFF)          // أسطح البطاقات أبيض ناصع يوفر تباينًا نظيفًا فوق الخلفية الرمادية
val SurfaceCardAlt = Color(0xFFE2E8F0)       // سطح ثانوي رمادي متدرج
val BorderSubtle = Color(0xFFCBD5E1)         // حدود ناعمة ومحددة للبطاقات (Slate 300)
val BorderMedium = Color(0xFF94A3B8)         // حدود الحقول النشطة (Slate 400)

// ألوان النصوص ذات التباين العالي وسهولة القراءة (لا تجعل النص رماديًا باهتًا)
val TextMain = Color(0xFF0F172A)             // النص الرئيسي كحلي داكن عالي التباين
val TextMuted = Color(0xFF334155)            // النص الثانوي رمادي داكن مقروء بوضوح (Slate 700)
val TextSubtle = Color(0xFF475569)           // التواريخ والملاحظات رمادي متوازن (Slate 600)
val TextInverted = Color(0xFFFFFFFF)

// ألوان الحالات (الأخضر للنجاح فقط، الأحمر للخطأ فقط، البرتقالي للتنبيه فقط)
val StatusSuccess = Color(0xFF16A34A)        // أخضر هادئ معتمد للنجاح (Green 600)
val StatusSuccessDark = Color(0xFF15803D)
val StatusSuccessContainer = Color(0xFFF0FDF4) // Green 50
val StatusSuccessBorder = Color(0xFF86EFAC)  // Green 300
val StatusSuccessText = Color(0xFF15803D)

val StatusError = Color(0xFFDC2626)          // أحمر هادئ للأخطاء والإجابات الخاطئة (Red 600)
val StatusErrorDark = Color(0xFFB91C1C)
val StatusErrorContainer = Color(0xFFFEF2F2) // Red 50
val StatusErrorBorder = Color(0xFFFCA5A5)    // Red 300
val StatusErrorText = Color(0xFFB91C1C)

val StatusWarning = Color(0xFFD97706)        // كهرماني هادئ للتنبيهات (Amber 600)
val StatusWarningDark = Color(0xFFB45309)
val StatusWarningContainer = Color(0xFFFFFBEB)
val StatusWarningBorder = Color(0xFFFCD34D)
val StatusWarningText = Color(0xFFB45309)

// Dark Palette Variants
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)

// Backwards-compatible Aliases
val SmartBlue = AccentBlue
val SmartBlueDark = PrimaryDark
val SmartBlueLight = AccentBlueLight
val SmartBlueContainer = AccentBlueContainer
val SmartBlueOnContainer = AccentBlueOnContainer

val ScientificPurple = Color(0xFF6366F1)
val ScientificPurpleLight = Color(0xFF818CF8)
val ScientificPurpleDark = Color(0xFF4F46E5)
val ScientificPurpleContainer = Color(0xFFEEF2FF)
val ScientificPurpleOnContainer = Color(0xFF3730A3)

val BackgroundLight = BackgroundCanvas
val SurfacePure = SurfaceCard
val SurfaceVariantLight = SurfaceCardAlt
val SurfaceBorder = BorderSubtle
val TextPrimaryNavy = TextMain
val TextSecondarySlate = TextMuted
val TextTertiarySlate = TextSubtle
val SuccessGreen = StatusSuccess
val SuccessGreenDark = StatusSuccessDark
val SuccessGreenContainer = StatusSuccessContainer
val SuccessGreenText = StatusSuccessText
val ErrorRed = StatusError
val ErrorRedDark = StatusErrorDark
val ErrorRedContainer = StatusErrorContainer
val ErrorRedText = StatusErrorText
val WarningOrange = StatusWarning
val WarningOrangeDark = StatusWarningDark
val WarningOrangeContainer = StatusWarningContainer
val WarningOrangeText = StatusWarningText
