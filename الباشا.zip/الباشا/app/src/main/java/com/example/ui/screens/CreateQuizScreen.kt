package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.QuizQuestion
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.AccentBlueContainer
import com.example.ui.theme.BackgroundCanvas
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.PrimaryDark
import com.example.ui.theme.PrimaryOnDark
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorBorder
import com.example.ui.theme.StatusErrorContainer
import com.example.ui.theme.StatusErrorText
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessBorder
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.StatusSuccessText
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSubtle
import com.example.ui.viewmodel.StudyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateQuizScreen(
    viewModel: StudyViewModel,
    onNavigateBack: () -> Unit,
    onQuizSubmitted: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeGuide by viewModel.activeGuide.collectAsStateWithLifecycle()
    val currentSession by viewModel.currentQuizSession.collectAsStateWithLifecycle()

    var selectedQuestionCount by remember { mutableIntStateOf(5) }
    var currentQuestionIndex by remember { mutableIntStateOf(0) }

    val isTakingQuiz = currentSession != null && !currentSession!!.isCompleted

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("quiz_screen"),
        containerColor = BackgroundCanvas,
        topBar = {
            TopAppBar(
                title = {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = if (isTakingQuiz) "اختبار: ${activeGuide.title}" else "إنشاء اختبار MCQ جديد",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextMain,
                            maxLines = 1
                        )
                        if (isTakingQuiz) {
                            Text(
                                text = "السؤال ${currentQuestionIndex + 1} من ${currentSession!!.totalQuestions}",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("back_from_quiz_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "رجوع",
                            tint = PrimaryDark
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceCard)
            )
        },
        bottomBar = {
            if (isTakingQuiz) {
                val session = currentSession!!
                val chosenAnswer = session.selectedAnswers[currentQuestionIndex]
                val isAnswered = chosenAnswer != null
                val isLastQuestion = currentQuestionIndex == session.questions.size - 1

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceCard)
                        .border(1.dp, BorderSubtle, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                        .navigationBarsPadding()
                ) {
                    Button(
                        onClick = {
                            if (isLastQuestion) {
                                viewModel.submitQuiz()
                                onQuizSubmitted()
                            } else {
                                currentQuestionIndex++
                            }
                        },
                        enabled = isAnswered,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("next_question_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PrimaryDark,
                            disabledContainerColor = Color(0xFFE2E8F0)
                        )
                    ) {
                        Text(
                            text = if (isLastQuestion) "إنهاء الاختبار وعرض النتيجة" else "السؤال التالي",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isAnswered) PrimaryOnDark else TextMuted
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        if (!isTakingQuiz) {
            // Setup Screen: Select Question Count (5 or 10) & Start
            QuizSetupView(
                guideTitle = activeGuide.title,
                selectedCount = selectedQuestionCount,
                onCountSelected = { selectedQuestionCount = it },
                onStart = {
                    currentQuestionIndex = 0
                    viewModel.startQuiz(selectedQuestionCount)
                },
                modifier = Modifier.padding(paddingValues)
            )
        } else {
            // Quiz In-Progress View
            val session = currentSession!!
            val currentQuestion = session.questions.getOrNull(currentQuestionIndex)

            if (currentQuestion != null) {
                val chosenAnswer = session.selectedAnswers[currentQuestionIndex]

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Thin Progress Indicator
                    item {
                        LinearProgressIndicator(
                            progress = { (currentQuestionIndex + 1f) / session.totalQuestions },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(5.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = AccentBlue,
                            trackColor = BorderSubtle,
                            strokeCap = StrokeCap.Round
                        )
                    }

                    // Question Card
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(SurfaceCard)
                                .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
                                .padding(18.dp)
                        ) {
                            Text(
                                text = currentQuestion.question,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextMain,
                                lineHeight = 24.sp
                            )
                        }
                    }

                    // 4 Options Cards
                    items(currentQuestion.options.entries.toList()) { (optionKey, optionText) ->
                        QuizOptionCard(
                            key = optionKey,
                            text = optionText,
                            isSelected = chosenAnswer == optionKey,
                            isAnswered = chosenAnswer != null,
                            isCorrect = optionKey == currentQuestion.correctAnswer,
                            onSelect = {
                                if (chosenAnswer == null) {
                                    viewModel.selectQuizAnswer(currentQuestionIndex, optionKey)
                                }
                            }
                        )
                    }

                    // Explanation Box (after answering)
                    if (chosenAnswer != null) {
                        item {
                            ExplanationCard(
                                isCorrect = chosenAnswer == currentQuestion.correctAnswer,
                                explanation = currentQuestion.explanation,
                                chapterName = currentQuestion.chapterName
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuizOptionCard(
    key: String,
    text: String,
    isSelected: Boolean,
    isAnswered: Boolean,
    isCorrect: Boolean,
    onSelect: () -> Unit
) {
    val (bgColor, borderColor, textColor, badgeBg, badgeText) = when {
        isAnswered && isCorrect -> {
            // Correct Option: Soft Green
            Tuple5(
                StatusSuccessContainer,
                StatusSuccessBorder,
                StatusSuccessText,
                StatusSuccess,
                Color.White
            )
        }
        isAnswered && isSelected && !isCorrect -> {
            // Chosen Wrong Option: Soft Red
            Tuple5(
                StatusErrorContainer,
                StatusErrorBorder,
                StatusErrorText,
                StatusError,
                Color.White
            )
        }
        isSelected -> {
            // Selected before confirmation
            Tuple5(
                AccentBlueContainer,
                AccentBlue,
                PrimaryDark,
                AccentBlue,
                Color.White
            )
        }
        else -> {
            // Default Neutral
            Tuple5(
                SurfaceCard,
                BorderSubtle,
                TextMain,
                Color(0xFFF1F5F9),
                PrimaryDark
            )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable(enabled = !isAnswered) { onSelect() }
            .padding(16.dp)
            .testTag("quiz_option_$key")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Key Indicator (أ، ب، ج، د)
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(badgeBg),
                contentAlignment = Alignment.Center
            ) {
                if (isAnswered && isCorrect) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "صحيح",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                } else if (isAnswered && isSelected && !isCorrect) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "خطأ",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                } else {
                    Text(
                        text = key,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = badgeText
                    )
                }
            }

            Text(
                text = text,
                fontSize = 14.sp,
                fontWeight = if (isSelected || (isAnswered && isCorrect)) FontWeight.Bold else FontWeight.Medium,
                color = textColor,
                lineHeight = 20.sp,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun ExplanationCard(
    isCorrect: Boolean,
    explanation: String,
    chapterName: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isCorrect) StatusSuccessContainer else Color(0xFFF8FAFC))
            .border(
                1.dp,
                if (isCorrect) StatusSuccessBorder else BorderSubtle,
                RoundedCornerShape(14.dp)
            )
            .padding(16.dp)
            .testTag("quiz_explanation_card")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = if (isCorrect) StatusSuccess else AccentBlue,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = if (isCorrect) "إجابة صحيحة! 👏" else "توضيح وتفسير الإجابة:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isCorrect) StatusSuccessText else PrimaryDark
                )
            }

            Text(
                text = explanation,
                fontSize = 13.sp,
                color = TextMuted,
                lineHeight = 20.sp
            )

            Text(
                text = "الفصل: $chapterName",
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = TextSubtle
            )
        }
    }
}

@Composable
private fun QuizSetupView(
    guideTitle: String,
    selectedCount: Int,
    onCountSelected: (Int) -> Unit,
    onStart: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(SurfaceCard)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(18.dp))
                    .padding(20.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "الملزمة المختارة للاختبار:",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Text(
                        text = guideTitle,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMain
                    )
                    Text(
                        text = "يتم توليد الأسئلة حصريًا من نصوص وفقرات الملزمة المحددة لضمان أقصى درجات الدقة الأكاديمية.",
                        fontSize = 12.sp,
                        color = TextMuted,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        item {
            Text(
                text = "اختر عدد الأسئلة:",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextMain
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CountChoiceCard(
                    count = 5,
                    label = "5 أسئلة",
                    subtitle = "اختبار سريع (3 دقائق)",
                    isSelected = selectedCount == 5,
                    onClick = { onCountSelected(5) },
                    modifier = Modifier.weight(1f)
                )

                CountChoiceCard(
                    count = 10,
                    label = "10 أسئلة",
                    subtitle = "اختبار شامل (6 دقائق)",
                    isSelected = selectedCount == 10,
                    onClick = { onCountSelected(10) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Button(
                onClick = onStart,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("start_quiz_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryDark)
            ) {
                Text(
                    text = "بدء الاختبار الآن",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryOnDark
                )
            }
        }
    }
}

@Composable
private fun CountChoiceCard(
    count: Int,
    label: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) AccentBlueContainer else SurfaceCard)
            .border(
                1.5.dp,
                if (isSelected) AccentBlue else BorderSubtle,
                RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .padding(16.dp)
            .testTag("quiz_count_choice_$count")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = label,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) AccentBlue else TextMain
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = TextMuted
            )
        }
    }
}

private data class Tuple5<A, B, C, D, E>(
    val a: A,
    val b: B,
    val c: C,
    val d: D,
    val e: E
)
