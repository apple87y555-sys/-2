package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.PdfGuideManager
import com.example.data.local.PdfProcessResult
import com.example.data.local.StudyTutorEngine
import com.example.data.model.ChatMessage
import com.example.data.model.DailyUsage
import com.example.data.model.QuizSession
import com.example.data.model.SenderType
import com.example.data.model.StudyGuide
import com.example.data.remote.GeminiBackendService
import com.example.data.remote.GeminiQueryResult
import com.example.data.repository.BannerStatus
import com.example.data.repository.StudyRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

sealed class UploadUiState {
    data object Idle : UploadUiState()
    data class Processing(val step: String, val progress: Float) : UploadUiState()
    data class Success(val guide: StudyGuide, val isCached: Boolean, val message: String) : UploadUiState()
    data class Error(val message: String) : UploadUiState()
}

sealed class AiGenerationState {
    data object Idle : AiGenerationState()
    data class Analyzing(val message: String = "جاري تحليل الملزمة...") : AiGenerationState()
    data class PreparingAnswer(val message: String = "جاري إعداد الإجابة من محتوى الملزمة...") : AiGenerationState()
    data class ConnectionError(val message: String = "فشل الاتصال بخدمة الذكاء الاصطناعي") : AiGenerationState()
}

class StudyViewModel(
    private val repository: StudyRepository = StudyRepository()
) : ViewModel() {

    val activeGuide: StateFlow<StudyGuide> = repository.activeGuide
    val allGuides: StateFlow<List<StudyGuide>> = repository.studyGuides
    val currentQuizSession: StateFlow<QuizSession?> = repository.currentQuizSession
    val completedQuizzes: StateFlow<List<QuizSession>> = repository.quizHistory
    val dailyUsage: StateFlow<DailyUsage> = repository.dailyUsage
    val bannerStatus: StateFlow<BannerStatus?> = repository.bannerStatus

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _aiState = MutableStateFlow<AiGenerationState>(AiGenerationState.Idle)
    val aiState: StateFlow<AiGenerationState> = _aiState.asStateFlow()

    private val _uploadState = MutableStateFlow<UploadUiState>(UploadUiState.Idle)
    val uploadState: StateFlow<UploadUiState> = _uploadState.asStateFlow()

    // Current chat messages for the active guide
    val activeChatMessages: StateFlow<List<ChatMessage>> = combine(
        repository.activeGuide,
        repository.chatMessagesMap
    ) { guide, map ->
        map[guide.id] ?: emptyList()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun initializeWithContext(context: Context) {
        repository.loadStoredGuides(context)
    }

    fun selectGuide(guideId: String) {
        repository.setActiveGuide(guideId)
    }

    fun uploadPdfFile(context: Context, uri: Uri, customSubject: String?) {
        viewModelScope.launch {
            _uploadState.value = UploadUiState.Processing("جاري رفع الملف وفحص الحجم (أقصى حد 20MB)...", 0.2f)

            val result = PdfGuideManager.processPdfUpload(
                context = context,
                uri = uri,
                customSubject = customSubject,
                onProgressUpdate = { step, progress ->
                    _uploadState.value = UploadUiState.Processing(step, progress)
                }
            )

            when (result) {
                is PdfProcessResult.Success -> {
                    val updatedList = (listOf(result.guide) + allGuides.value).distinctBy { it.id }
                    repository.setActiveGuide(result.guide.id)
                    _uploadState.value = UploadUiState.Success(
                        guide = result.guide,
                        isCached = result.isCached,
                        message = result.message
                    )
                    repository.setBanner(BannerStatus.Success(result.message))
                }
                is PdfProcessResult.Error -> {
                    _uploadState.value = UploadUiState.Error(result.errorMessage)
                    repository.setBanner(BannerStatus.Error("فشل الرفع: ${result.errorMessage}"))
                }
            }
        }
    }

    fun resetUploadState() {
        _uploadState.value = UploadUiState.Idle
    }

    fun uploadCustomGuide(title: String, subject: String, rawContent: String) {
        viewModelScope.launch {
            _isGenerating.value = true
            _uploadState.value = UploadUiState.Processing("جاري تحليل الملزمة وتوليد الفصول...", 0.6f)
            delay(500)
            val newGuide = repository.addCustomGuide(title, subject, rawContent)
            _uploadState.value = UploadUiState.Success(
                guide = newGuide,
                isCached = false,
                message = "تمت معالجة محتوى الملزمة بنجاح وحفظها كملزمة نشطة!"
            )
            _isGenerating.value = false
        }
    }

    fun sendUserMessage(text: String) {
        if (text.isBlank() || _isGenerating.value) return

        val guide = activeGuide.value
        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            guideId = guide.id,
            sender = SenderType.USER,
            text = text.trim()
        )
        repository.addChatMessage(guide.id, userMsg)

        viewModelScope.launch {
            _isGenerating.value = true
            _aiState.value = AiGenerationState.Analyzing("جاري تحليل الملزمة...")
            delay(300)
            _aiState.value = AiGenerationState.PreparingAnswer("جاري إعداد الإجابة من محتوى الملزمة...")

            val localPdf = guide.localPdfPath?.let { File(it) }?.takeIf { it.exists() }
            val geminiResult = if (GeminiBackendService.isApiKeyConfigured()) {
                GeminiBackendService.askGemini(
                    geminiFileUri = guide.geminiFileUri,
                    localPdfFile = localPdf,
                    rawTextContent = guide.rawText,
                    studentQuestion = text.trim()
                )
            } else {
                null
            }

            val assistantResponse = when (geminiResult) {
                is GeminiQueryResult.Success -> {
                    ChatMessage(
                        id = UUID.randomUUID().toString(),
                        guideId = guide.id,
                        sender = SenderType.ASSISTANT,
                        text = geminiResult.answer,
                        citedSection = "الملزمة المرفوعة: ${guide.title}",
                        suggestedFollowUps = listOf(
                            "وضح لي أكثر من الملزمة",
                            "أعطني مثالاً تطبيقياً",
                            "اختبرني في هذه النقطة"
                        )
                    )
                }
                is GeminiQueryResult.ConnectionError -> {
                    _aiState.value = AiGenerationState.ConnectionError(geminiResult.message)
                    repository.setBanner(BannerStatus.Error("فشل الاتصال: ${geminiResult.message}"))
                    // Fallback to strict source-grounded engine
                    StudyTutorEngine.answerStudentQuestion(guide, text.trim())
                }
                is GeminiQueryResult.GeneralError -> {
                    // Fallback to strict source-grounded engine
                    StudyTutorEngine.answerStudentQuestion(guide, text.trim())
                }
                null -> {
                    // Local fallback
                    StudyTutorEngine.answerStudentQuestion(guide, text.trim())
                }
            }

            repository.addChatMessage(guide.id, assistantResponse)
            _isGenerating.value = false
            _aiState.value = AiGenerationState.Idle
        }
    }

    fun startQuiz(questionCount: Int) {
        repository.startQuizSession(questionCount)
    }

    fun selectQuizAnswer(questionIndex: Int, chosenKey: String) {
        repository.updateQuizAnswer(questionIndex, chosenKey)
    }

    fun submitQuiz(): QuizSession? {
        return repository.submitCurrentQuiz()
    }

    fun discussMistakesInChat() {
        val session = currentQuizSession.value ?: return
        val incorrect = session.questions.filterIndexed { index, q ->
            val chosen = session.selectedAnswers[index]
            chosen != null && chosen != q.correctAnswer
        }
        val prompt = if (incorrect.isNotEmpty()) {
            "أود مناقشة الأسئلة التي أخطأت فيها في الاختبار الأخير لتوضيح المفاهيم: " +
                    incorrect.joinToString(" ، ") { it.question }
        } else {
            "لخص لي أهم المفاهيم التي وردت في الاختبار لأراجعها."
        }
        sendUserMessage(prompt)
    }

    fun dismissBanner() {
        repository.setBanner(null)
    }

    fun triggerQueueWarningDemo() {
        repository.setBanner(BannerStatus.Warning("جاري تنظيم الدور بسبب الضغط على الخادم، شكرًا لصبرك!"))
    }

    fun triggerConnectionErrorDemo() {
        repository.setBanner(BannerStatus.Error("انقطاع الاتصال المؤقت، المساعد يعمل الآن في وضع المذاكرة دون إنترنت."))
    }
}
