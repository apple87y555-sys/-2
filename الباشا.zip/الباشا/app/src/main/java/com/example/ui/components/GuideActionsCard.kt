package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.AccentBlueContainer
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.PrimaryDark
import com.example.ui.theme.PrimaryOnDark
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMain
import com.example.ui.theme.TextMuted

@Composable
fun GuideActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    accentBg: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "guide_action_card"
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceCard)
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(16.dp)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accentBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMain
                )
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = TextMuted
                )
            }
        }
    }
}

@Composable
fun GuideThreeActionsGroup(
    onAskGuide: () -> Unit,
    onSummarizeGuide: () -> Unit,
    onTakeQuiz: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        GuideActionCard(
            title = "اسأل الملزمة",
            subtitle = "محادثة ذكية للإجابة عن أي سؤال مقتطع من الملزمة",
            icon = Icons.AutoMirrored.Filled.Chat,
            accentColor = AccentBlue,
            accentBg = AccentBlueContainer,
            onClick = onAskGuide,
            testTag = "action_ask_guide_card"
        )

        GuideActionCard(
            title = "لخص الملزمة",
            subtitle = "عرض ملخص شامل لأهم المفاهيم والقواعد والتعريفات",
            icon = Icons.Default.AutoStories,
            accentColor = PrimaryDark,
            accentBg = Color(0xFFF1F5F9),
            onClick = onSummarizeGuide,
            testTag = "action_summarize_guide_card"
        )

        GuideActionCard(
            title = "اختبر نفسك",
            subtitle = "توليد اختبار اختيار من متعدد (MCQ) لقياس مستوى فهمك",
            icon = Icons.Default.Quiz,
            accentColor = Color(0xFF16A34A),
            accentBg = Color(0xFFF0FDF4),
            onClick = onTakeQuiz,
            testTag = "action_quiz_guide_card"
        )
    }
}
