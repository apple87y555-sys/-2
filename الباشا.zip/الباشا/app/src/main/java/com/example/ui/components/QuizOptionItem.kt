package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedContainer
import com.example.ui.theme.ErrorRedText
import com.example.ui.theme.SmartBlue
import com.example.ui.theme.SmartBlueContainer
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenContainer
import com.example.ui.theme.SuccessGreenText
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfacePure
import com.example.ui.theme.TextPrimaryNavy
import com.example.ui.theme.TextSecondarySlate

enum class OptionReviewState {
    DEFAULT,
    SELECTED_IN_PROGRESS,
    CORRECT,
    WRONG
}

@Composable
fun QuizOptionItem(
    optionKey: String, // "أ", "ب", "ج", "د"
    optionText: String,
    state: OptionReviewState = OptionReviewState.DEFAULT,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val (bgColor, borderColor, badgeBg, badgeTextColor, textColor) = when (state) {
        OptionReviewState.DEFAULT -> arrayOf(
            SurfacePure,
            SurfaceBorder,
            Color(0xFFF1F5F9),
            TextSecondarySlate,
            TextPrimaryNavy
        )
        OptionReviewState.SELECTED_IN_PROGRESS -> arrayOf(
            SmartBlueContainer,
            SmartBlue,
            SmartBlue,
            Color.White,
            TextPrimaryNavy
        )
        OptionReviewState.CORRECT -> arrayOf(
            SuccessGreenContainer,
            SuccessGreen,
            SuccessGreen,
            Color.White,
            SuccessGreenText
        )
        OptionReviewState.WRONG -> arrayOf(
            ErrorRedContainer,
            ErrorRed,
            ErrorRed,
            Color.White,
            ErrorRedText
        )
    }

    val clickableModifier = if (onClick != null) {
        Modifier.clickable { onClick() }
    } else Modifier

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor as Color)
            .border(1.5.dp, borderColor as Color, RoundedCornerShape(12.dp))
            .then(clickableModifier)
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .testTag("quiz_option_$optionKey"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Option key circle badge (أ, ب, ج, د)
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(badgeBg as Color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = optionKey,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = badgeTextColor as Color
            )
        }

        Text(
            text = optionText,
            fontSize = 14.sp,
            fontWeight = if (state == OptionReviewState.SELECTED_IN_PROGRESS || state == OptionReviewState.CORRECT) FontWeight.SemiBold else FontWeight.Normal,
            color = textColor as Color,
            lineHeight = 20.sp,
            modifier = Modifier.weight(1f)
        )
    }
}
