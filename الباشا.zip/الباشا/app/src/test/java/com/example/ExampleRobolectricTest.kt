package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.PdfGuideManager
import com.example.data.local.SampleStudyGuides
import com.example.data.local.StudyTutorEngine
import com.example.data.model.StudyGuide
import com.example.data.remote.GeminiBackendService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("زاكرلي", appName)
    }

    @Test
    fun `test out of scope response strictly matches mandate`() {
        val guide = SampleStudyGuides.biologyGuide
        val response = StudyTutorEngine.answerStudentQuestion(guide, "ما هي عاصمة فرنسا وكم عدد سكانها؟")
        assertEquals(
            "عذرًا، هذه المعلومة غير متوفرة في الملزمة المرفوعة. أسئلتي مقتطعة من محتوى المادة فقط لضمان دقة معلوماتك.",
            response.text
        )
    }

    @Test
    fun `test gemini system prompt contains exact out of scope mandate`() {
        assertTrue(
            GeminiBackendService.SYSTEM_PROMPT.contains(
                "عذرًا، هذه المعلومة غير متوفرة في الملزمة المرفوعة. أسئلتي مقتطعة من محتوى المادة فقط لضمان دقة معلوماتك."
            )
        )
    }

    @Test
    fun `test quiz creation adheres to question counts`() {
        val guide = SampleStudyGuides.biologyGuide
        val session5 = StudyTutorEngine.createQuizSession(guide, 5)
        assertEquals(5, session5.questions.size)

        val session10 = StudyTutorEngine.createQuizSession(guide, 10)
        assertEquals(10, session10.questions.size)
    }

    @Test
    fun `test persistent storage save and load with gemini metadata`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sampleGuide = StudyGuide(
            id = "pdf_test_hash_gemini_123",
            title = "ملزمة تجريبية لاختبار Gemini",
            subject = "الفيزياء الحديثة",
            gradeLevel = "المرحلة الثانوية",
            description = "وصف للملزمة المحفوظة",
            totalPages = 14,
            totalWords = 4200,
            uploadDate = "2026/08/19",
            iconType = "doc",
            chapters = emptyList(),
            rawText = "محتوى فيزيائي تجريبي",
            geminiFileUri = "https://generativelanguage.googleapis.com/v1beta/files/test_123",
            geminiFileId = "files/test_123"
        )

        PdfGuideManager.saveGuideToManifest(context, sampleGuide)
        val loaded = PdfGuideManager.loadPersistedGuides(context)

        assertTrue(loaded.any { it.id == "pdf_test_hash_gemini_123" })
        val matched = loaded.first { it.id == "pdf_test_hash_gemini_123" }
        assertEquals("ملزمة تجريبية لاختبار Gemini", matched.title)
        assertEquals("https://generativelanguage.googleapis.com/v1beta/files/test_123", matched.geminiFileUri)
    }
}
